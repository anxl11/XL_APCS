    yertle.turnRight();
    yertle.forward();